#include "mii.h"

#include <stdio.h>
#include <stdlib.h>
#include <isfs/isfs.h>
#include <string.h>

#define FACELIB_Wii "isfs://shared2/menu/FaceLib/RFL_DB.dat"

Mii miis[MII_MAX];

char * read(char * path){
	long Size;
	FILE * File;
	char * buffer;
	File = fopen(path, "rb");
	if (File==NULL) {
		printf("%s does not exist\n", path);
		return NULL;
	}
	//fseek (File, 0, SEEK_END);
	//Size = ftell (File);
	//rewind (File);
	Size = 800000;
	buffer = (char*) malloc (sizeof(char)*Size);
	fread(buffer,1,Size,File);
	fclose (File);
	return buffer;
}

void loadMiis_Wii(){
	ISFS_SU();
	ISFS_Initialize();
	ISFS_Mount();

	char * data;
	data = read(FACELIB_Wii);
	if (data!=NULL) loadMiis(data);

	ISFS_Unmount();
}

int getInt_Bin(char hex, int start, int end){
	int i;
	int n = 0;
	for (i=0;i<end-start;i++){
		if (hex & (2 ^ (start + i - 1))){
			n += (2 ^ i);
		}
	}
	return n;
}

Mii loadMii(int start, char * data){
	Mii mii;
	int c;
	for (c=0;c<MII_NAME_LENGTH;c++)
		mii.name[c] = data[start + 0x02 + c * 2 + 1];
	if (mii.name == ""){
		mii.invalid = 1;
		return mii;
	}
	for (c=0;c<MII_CREATOR_NAME_LENGTH;c++)
		mii.creator[c] = data[start + 0x36 + c * 2 + 1];
	mii.female = data[start] & 2;
	mii.month = getInt_Bin(data[start], 3, 6);
	mii.day = getInt_Bin(data[start]+data[start+0x01], 7, 12);
	mii.favColor = getInt_Bin(data[start+0x01], 5, 7);
	mii.favorite = data[start+1] & 8;
	mii.weight = data[start + 0x16];
	mii.height = data[start + 0x17];
	mii.miiID1 = getInt_Bin(data[start + 0x18], 1, 8);
	mii.miiID2 = getInt_Bin(data[start + 0x19], 1, 8);
	mii.miiID3 = getInt_Bin(data[start + 0x1A], 1, 8);
	mii.miiID4 = getInt_Bin(data[start + 0x1B], 1, 8);
	mii.systemID0 = getInt_Bin(data[start + 0x1C], 1, 8);
	mii.systemID1 = getInt_Bin(data[start + 0x1D], 1, 8);
	mii.systemID2 = getInt_Bin(data[start + 0x1E], 1, 8);
	mii.systemID3 = getInt_Bin(data[start + 0x1F], 1, 8);
	mii.faceShape = getInt_Bin(data[start + 0x20], 1, 3);
	mii.skinColor = getInt_Bin(data[start + 0x20], 4, 7);
	mii.facialFeature = getInt_Bin(data[start + 0x21], 1, 4);
	mii.mingleOff = data[start+0x21] & 8192;
	mii.hairType = getInt_Bin(data[start+0x22], 1, 7);
	mii.hairColor = getInt_Bin(data[start+0x22]+data[start+0x23], 8, 11);
	mii.hairPart = data[start+0x23] & 1024;
	mii.eyebrowType = getInt_Bin(data[start+0x24], 1, 5);
	mii.eyebrowRotation = getInt_Bin(data[start+0x24]+data[start+0x25], 7, 11);
	mii.eyebrowColor = getInt_Bin(data[start+0x25], 1, 3);
	mii.eyebrowSize = getInt_Bin(data[start+0x25], 4, 8);
	mii.eyebrowVertPos = getInt_Bin(data[start+0x26], 1, 6);
	mii.eyebrowHorizSpacing = getInt_Bin(data[start+0x26], 7, 8);
	mii.eyeType = getInt_Bin(data[start+0x28], 1, 6);
	mii.eyeRotation = getInt_Bin(data[start+0x29], 1, 4);
	mii.eyeVertPos = getInt_Bin(data[start+0x28], 5, 8);
	mii.eyeColor = getInt_Bin(data[start+0x29], 1, 3);
	mii.eyeSize = getInt_Bin(data[start+0x29], 5, 8);
	mii.eyeHorizSpacing = getInt_Bin(data[start+0x2A], 1, 5);
	mii.noseType = getInt_Bin(data[start+0x2C], 1, 4);
	mii.noseSize = getInt_Bin(data[start+0x2C], 5, 8);
	mii.noseVertPos = getInt_Bin(data[start+0x2C], 9, 13);
	mii.lipType = getInt_Bin(data[start+0x2E], 1, 5);
	mii.lipColor = getInt_Bin(data[start+0x2E], 6, 7);
	mii.lipSize = getInt_Bin(data[start+0x2E], 8, 11);
	mii.lipVertPos = getInt_Bin(data[start+0x2E], 12, 16);
	mii.glassesType = getInt_Bin(data[start+0x2F], 1, 4);
	mii.glassesColor = getInt_Bin(data[start+0x2F], 5, 7);
	mii.glassesSize = getInt_Bin(data[start+0x2F], 9, 11);
	mii.glassesVertPos = getInt_Bin(data[start+0x2F], 12, 16);
	mii.mustacheType = getInt_Bin(data[start+0x32], 1, 2);
	mii.beardType = getInt_Bin(data[start+0x32], 3, 4);
	mii.facialHairColor = getInt_Bin(data[start+0x2F], 5, 7);
	mii.mustacheSize = getInt_Bin(data[start+0x2F], 8, 11);
	mii.mustacheVertPos = getInt_Bin(data[start+0x2F], 12, 16);
	mii.mole = data[start+0x34] & 1;
	mii.moleSize = getInt_Bin(data[start+0x34], 2, 5);
	mii.moleVertPos = getInt_Bin(data[start+0x34], 6, 10);
	mii.moleHorizPos = getInt_Bin(data[start+0x34], 11, 15);
	return mii;
}

void loadMiis(char * data){
	if (data[0] == 'R' && data[1] == 'N' && data[2] == 'O' && data[3] == 'D'){
		int start;
		int n = 0;
		int cur = 0;
		Mii mii;
		for (n=0;(n+1) * MII_SIZE + 4 <= 124 * MII_SIZE;n++){
			start = n * MII_SIZE + 4;
			mii = loadMii(start, data);
			if (mii.invalid){
				continue;
			} else {
				miis[n] = mii;
				cur++;
			}
		}
	} else {
		printf("Version %c%c%c%c is not compatible with LibMii\n", data[0], data[1], data[2], data[3]);
	}
}
