#include <wiiuse/wpad.h>
#include <ogc/video.h>
#include <mii.h>
#include <stdio.h>
#include <stdlib.h>

static void *xfb = NULL;
static GXRModeObj *rmode = NULL;

void init(){
	VIDEO_Init();
	WPAD_Init();
	rmode = VIDEO_GetPreferredMode(NULL);
	xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
	console_init(xfb,20,20,rmode->fbWidth,rmode->xfbHeight,rmode->fbWidth*VI_DISPLAY_PIX_SZ);
	VIDEO_Configure(rmode);
	VIDEO_SetNextFramebuffer(xfb);
	VIDEO_SetBlack(FALSE);
	VIDEO_Flush();
	VIDEO_WaitVSync();
	if(rmode->viTVMode&VI_NON_INTERLACE) VIDEO_WaitVSync();
	printf("\x1b[2;0H");
}

void wait(){}

void showMii(Mii mii){
	printf("Press Left and Right on the Wii mote to navigate through your Miis\n\n");

	printf("Name: %s\nBy: %s\n", mii.name, mii.creator);
	if (mii.female) printf("This Mii is a girl\n");
	else printf("This Mii is a boy\n");

	printf("Birthday: %i/%i", mii.month, mii.day);
}

int MiiLen(Mii miis[]){return sizeof(miis)/sizeof(Mii);}
void clearScreen(){printf("\033[2J");printf("\x1b[2;0H");}

void diversityDay(){
	printf("This will test to see how diverse your Miis are!\n");
	int n;
	for (n=0;n<MiiLen(miis);n++){}
}

/*void test(){
	expansion_t *exp;
	vec3w_t *accel;
	gforce_t *gforce;
	orient_t *orientation;
	ir_t *ir;

	WPAD_IR(0, ir);
	WPAD_Orientation(0, orientation);
	WPAD_GForce(0, gforce);
	WPAD_Accel(0, accel);
	WPAD_Expansion(0, exp);
}*/

int main(){
	init();

	loadMiis_Wii();

	int n = 0;

	showMii(miis[n]);

	for(;;) {
		WPAD_ScanPads();
		u32 pressed = WPAD_ButtonsDown(0);
		if (pressed & WPAD_BUTTON_RIGHT){
			clearScreen();
			n+=1;
			showMii(miis[n]);
		} else if (pressed & WPAD_BUTTON_LEFT && n>0) {
			clearScreen();
			n-=1;
			showMii(miis[n]);
		} else if (pressed & WPAD_BUTTON_HOME){
			break;
		} else if (pressed & WPAD_BUTTON_B) {
			clearScreen();
			showMii(miis[n]);
		}
		VIDEO_WaitVSync();
	}

	return 0;
}
