#include <wiiuse/wpad.h>
#include <ogc/video.h>
#include <mii.h>
#include <stdio.h>
#include <stdlib.h>

static void *xfb = NULL;
static GXRModeObj *rmode = NULL;

void init(){
	VIDEO_Init();
	WPAD_Init();
	rmode = VIDEO_GetPreferredMode(NULL);
	xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
	console_init(xfb,20,20,rmode->fbWidth,rmode->xfbHeight,rmode->fbWidth*VI_DISPLAY_PIX_SZ);
	VIDEO_Configure(rmode);
	VIDEO_SetNextFramebuffer(xfb);
	VIDEO_SetBlack(FALSE);
	VIDEO_Flush();
	VIDEO_WaitVSync();
	if(rmode->viTVMode&VI_NON_INTERLACE) VIDEO_WaitVSync();
	printf("\x1b[2;0H");
}

void showMii(Mii mii){
	printf("Press Left and Right on the Wii mote to navigate through your Miis\n\n");

	printf("Name: %s\nBy: %s\n", mii.name, mii.creator);

	if (mii.month>0 && mii.day>0)
		printf("Birthday: %i/%i\n", mii.month, mii.day);
	printf("Favorite Color: %i\n", mii.favColor);
	if (mii.mingleOff) printf("Mingle: off\n");
	else printf("Mingle: on\n");
	printf("Skin: %i\n", mii.skinColor);
	printf("Hair Color: %i\n", mii.hairColor);


	if (mii.female)
	printf( "   _____		\n"
			" // ^_^ \\		\n"
			"//\_____/\\	\n");
	else
	printf( "   _____ 	\n"
			"  / ^_^ \	\n"
			"  \_____/	\n");

	int i;
	int n;
	for (i=0;i<mii.height/20;i++){
	printf(	"     |");
	for (n=0;n<mii.weight/20;n++)
	printf(	" ");
	printf(	"|	\n");
	}

	if (mii.female)
	printf(	"    /\		\n"
			"   /  \		\n"
			"  /    \	\n"
			" |_\   |_\	\n");
	else
	printf(	" | | | |	\n"
			" | | |	|	\n"
			" |_| |_|	\n"
			" |_+ |_+	\n");
}

int MiiLen(Mii miis[]){return sizeof(miis)/sizeof(Mii);}
void clearScreen(){printf("\033[2J");printf("\x1b[2;0H");}

int main(){
	init();

	loadMiis_Wii();

	int n = 0;

	for(;;) {
		WPAD_ScanPads();
		u32 pressed = WPAD_ButtonsDown(0);
		if ((pressed & WPAD_BUTTON_RIGHT || pressed & WPAD_BUTTON_2 || pressed & WPAD_BUTTON_PLUS || pressed & WPAD_BUTTON_DOWN) && miis[n+1].name!=""){
			clearScreen();
			n+=1;
			showMii(miis[n]);
		} else if ((pressed & WPAD_BUTTON_LEFT || pressed & WPAD_BUTTON_1 || pressed & WPAD_BUTTON_MINUS || pressed & WPAD_BUTTON_UP) && n>0) {
			clearScreen();
			n-=1;
			showMii(miis[n]);
		} else if (pressed & WPAD_BUTTON_HOME){
			clearScreen();
			printf("Goodbye!\n");
			break;
		} else if (pressed & WPAD_BUTTON_B) {
			clearScreen();
			showMii(miis[n]);
		} else if (pressed & WPAD_BUTTON_1 && pressed & WPAD_BUTTON_2){
			printf("In the future this may show your MiiNA number\n");
		}
		VIDEO_WaitVSync();
	}

	return 0;
}
